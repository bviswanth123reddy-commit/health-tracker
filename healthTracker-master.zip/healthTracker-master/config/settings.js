module.exports = {
  secret: 'healthTrackingApp'
};
