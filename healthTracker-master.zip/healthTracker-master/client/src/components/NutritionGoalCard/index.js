
export { default } from './NutritionGoalCard';

